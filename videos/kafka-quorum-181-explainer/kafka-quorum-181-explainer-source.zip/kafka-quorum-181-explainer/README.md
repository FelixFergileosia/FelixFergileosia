# Kafka di 177 sehat, kenapa ikut lumpuh saat 181 mati?

Video 1920×1080, 30 fps, voiceover Bahasa Indonesia, untuk developer dan tim IT internal pemakai
Kafka (collector backend, oracle relay). Pesan utama: **kafka-1 di host 177 tidak rusak. Ia "mati
suri" karena kalah suara di quorum KRaft, lalu pulih sendiri. Akar masalahnya desain: 2 dari 3
voter ada di host 181.**

Semua angka di video berasal dari log & metrik nyata 28–30 Oktober 2026 (Apache Kafka 4.1.2, mode
KRaft). Arah perbaikan di adegan 8 adalah *pilihan*, belum ada yang dikerjakan. Perilaku "restart
kafka-1 akan tertahan di STARTING" adalah perilaku KRaft yang belum teramati langsung, dan risiko
kehilangan pesan di sisi aplikasi belum dicek di konfigurasi producer aplikasi.

## Isi folder

| Path | Isi |
|---|---|
| `out/kafka-quorum-181-explainer.mp4` | video final (H.264 + AAC 48 kHz stereo, loudness −16 LUFS) |
| `out/kafka-quorum-181-explainer.srt` | subtitle, waktunya dari audio narasi (angka tampil sebagai angka) |
| `audio/scene_01.wav … scene_08.wav` | narasi per adegan (mentah, sebelum normalisasi) |
| `src/narration.py` | naskah narasi, ejaan ulang untuk mesin suara, angka → kata untuk TTS |
| `src/tts.py` | sintesis suara Piper per kalimat, pilih kandidat terbaik via Whisper, tulis `build/timing.json` |
| `src/gfx.py`, `src/components.py` | primitif gambar (anti-aliasing), host, kartu node, kursi voter, meter suara, penghitung, log, caption |
| `src/scenes.py` | 8 adegan; animasi ditambatkan ke waktu kalimat/kata narasi |
| `src/render.py` | render frame → ffmpeg, gabung audio, loudnorm 2-pass, tulis .srt |
| `src/asr_check.py`, `src/sync_check.py` | pemeriksaan audio (Whisper) dan sinkronisasi isyarat animasi |
| `laporan/` | still tengah tiap adegan, `tts_selection.txt`, `asr_report.txt`, `sync_report.txt`, `timing.json` |

## Adegan

1. Judul — 3 node di 2 host, "Kafka tidak mati, ia kalah suara."
2. Topologi — node 1 di 177, node 2 & 3 di 181; RF=3, `min.insync.replicas=2`.
3. Aturan mayoritas — 3 kursi voter, butuh 2; 177 mati → 2 suara ✅, 181 mati → 1 suara ❌.
4. Malam 29 Okt ±19:17 — 181 reboot; kafka-1 tetap running, 7.214 pre-vote, 80 Candidate, 69.458 baris log.
5. Apa yang berhenti — produce ❌, consumer group ❌ (4.144 timeout), consume data lama ⚠, bikin topic ❌, container ✅ running.
6. 22:25:32 — 181 kembali, controller terpilih, replikasi jalan; data aman, aplikasi wajib simpan + retry.
7. Jebakan — pindah voter ke 177 (titik gagal pindah), restart kafka-1 (tertahan di STARTING).
8. Ringkasan + tiga pilihan perbaikan.

## Cara menjalankan ulang

```bash
pip install piper-tts sherpa-onnx soundfile pillow numpy
# font: Inter (/usr/share/fonts/opentype/inter) dan DejaVu Sans Mono; ffmpeg di PATH
# model suara: vits-piper-id_ID-news_tts-medium (rilis "tts-models" k2-fsa/sherpa-onnx di GitHub) -> models/
# model Whisper (untuk memilih kandidat & cek): sherpa-onnx-whisper-small (rilis "asr-models") -> models/asr/
python3 src/tts.py            # audio + timing.json + tts_selection.txt
python3 src/asr_check.py      # opsional: build/asr_report.txt
python3 src/sync_check.py     # opsional: build/sync_report.txt
python3 src/render.py stills  # PNG pemeriksaan per adegan -> build/check/
python3 src/render.py all     # video final + srt -> out/
```

Ubah naskah di `src/narration.py`, lalu jalankan `tts.py` dan `render.py all` lagi; durasi dan
semua isyarat animasi menyesuaikan sendiri.

### Catatan naskah

- Teks di `SCENES` adalah teks tampil (subtitle): angka ditulis sebagai angka. `to_tts()` mengeja
  ulang istilah (`TTS_RESPELL`, frasa panjang dulu) lalu mengubah angka menjadi kata
  (`7.214` → "tujuh ribu dua ratus empat belas", `19.17` → "sembilan belas tujuh belas").
- `asr_check.py` dan pemilihan kandidat di `tts.py` mengubah angka di naskah *dan* di hasil
  Whisper menjadi kata sebelum dibandingkan, jadi ucapan angka ikut diperiksa.
