"""Pemeriksaan audio: transkripsi tiap klip narasi dengan Whisper (offline, sherpa-onnx)
lalu dibandingkan dengan naskah. Kata yang tidak dikenali Whisper ditandai untuk diperiksa.
Keluaran: build/asr_report.txt"""
import json
import sys
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np
import sherpa_onnx
import soundfile as sf

sys.path.insert(0, str(Path(__file__).parent))
from tts import norm_words as norm  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
M = ROOT / "models/asr/sherpa-onnx-whisper-small"


def main():
    rec = sherpa_onnx.OfflineRecognizer.from_whisper(
        encoder=str(M / "small-encoder.int8.onnx"), decoder=str(M / "small-decoder.int8.onnx"),
        tokens=str(M / "small-tokens.txt"), language="id", task="transcribe", num_threads=2)
    timing = json.loads((ROOT / "build/timing.json").read_text())
    out = []
    scores = []
    for sid, sc in timing.items():
        for seg in sc["segments"]:
            a, sr = sf.read(ROOT / f"build/audio/clips/s{sid}_{seg['key']}.wav", dtype="float32")
            pad = np.zeros(int(sr * 0.3), np.float32)
            st = rec.create_stream()
            st.accept_waveform(sr, np.concatenate([pad, a, pad]))
            rec.decode_stream(st)
            hyp = st.result.text.strip()
            ref_w, hyp_w = norm(seg["text"]), norm(hyp)
            sm = SequenceMatcher(None, ref_w, hyp_w)
            ratio = sm.ratio()
            scores.append(ratio)
            diffs = [f"{' '.join(ref_w[i1:i2])!r}->{' '.join(hyp_w[j1:j2])!r}"
                     for op, i1, i2, j1, j2 in sm.get_opcodes() if op != "equal"]
            out.append(f"[{sid}/{seg['key']}] kecocokan {ratio:.2f}\n  naskah : {seg['text']}\n  whisper: {hyp}\n"
                       + (f"  beda   : {'; '.join(diffs)}\n" if diffs else ""))
    out.append(f"rata-rata kecocokan kata: {sum(scores)/len(scores):.3f}")
    (ROOT / "build/asr_report.txt").write_text("\n".join(out))
    print("\n".join(out))


if __name__ == "__main__":
    main()
