"""Komponen visual: host, kartu node Kafka, kursi voter, meter suara, penghitung, kartu log,
caption, dan pembantu waktu yang menambatkan animasi ke narasi."""
import json
import math
from bisect import bisect_right
from pathlib import Path

from gfx import (BG, BLUE, BLUE_BG, GREEN, GREEN_BG, INK, LINE, MUTED, RED, RED_BG, WHITE, YELLOW,
                 YELLOW_BG, circle, font, group, icon_check, icon_cross, icon_server, line, mix, pill,
                 rrect, shadow_card, text, tw, wrap)
from narration import to_tts

ROOT = Path(__file__).resolve().parent.parent

# ================= DATA (persis dari log & metrik 28–30 Okt 2026) =================
# (nomor node, container, host, port controller)
NODES = [(1, "kafka-1", "177", "19093"), (2, "kafka-2", "181", "19093"), (3, "kafka-3", "181", "19094")]
HOST_IP = {"177": "192.168.19.177", "181": "192.168.19.181"}
GROUPS = ["collector-backend-consumer-group-server", "oracle-relay-integration"]
N_PREVOTE = 7214
N_CANDIDATE = 80
N_LOGLINES = 69458
N_GROUP_TIMEOUT = 4144

# cuplikan log kafka-1 (disederhanakan; kalimat bahasa Inggris = pesan asli di log)
LOG_LINES = [
    ("Prospective", "pre-vote: minta suara ke node 2, node 3", YELLOW),
    ("Raft", "Election timed out before receiving sufficient vote responses", RED),
    ("Candidate", "mencalonkan diri, suara: 1 dari 3", YELLOW),
    ("Fetcher", "salin dari node 3: tidak terjangkau", MUTED),
    ("GroupCoordinator", "... write event Timeout", RED),
]

GREY = (0xA9, 0xB3, 0xAD)
GREY_BG = (0xE7, 0xEB, 0xE8)
HOST_BG = (0xEC, 0xF0, 0xED)


def fmt_id(n):
    """7214 -> '7.214' (pemisah ribuan gaya Indonesia)."""
    return f"{n:,}".replace(",", ".")


# ================= waktu =================
class Timing:
    def __init__(self, sid):
        data = json.loads((ROOT / "build/timing.json").read_text())[str(sid)]
        self.dur = data["dur"]
        self.seg = {s["key"]: s for s in data["segments"]}

    def s(self, key):
        return self.seg[key]["start"]

    def e(self, key):
        return self.seg[key]["end"]

    def w(self, key, phrase, occ=1):
        """Perkiraan detik saat frasa mulai diucapkan di dalam kalimat `key`."""
        sg = self.seg[key]
        txt = sg["text"]
        idx = -1
        for _ in range(occ):
            idx = txt.index(phrase, idx + 1)
        c = len(to_tts(txt[:idx]))
        ac, at = sg["anchors_c"], sg["anchors_t"]
        i = max(0, min(bisect_right(ac, c) - 1, len(ac) - 2))
        f = (c - ac[i]) / max(1, ac[i + 1] - ac[i])
        return at[i] + (at[i + 1] - at[i]) * f


# ================= bingkai adegan =================
def chrome(im, sid, title, example=False):
    text(im, (56, 66), title, font("bold", 40), INK, anchor="lm")
    f = font("semi", 28)
    box = pill(im, 1864, 66, f"{sid}/8", f, fg=MUTED, bg=WHITE, anchor="r", outline=LINE, padx=16, h=46)
    if example:
        pill(im, box[0] - 14, 66, "contoh", f, fg=YELLOW, bg=YELLOW_BG, anchor="r",
             outline=YELLOW, padx=16, h=46)
    return box


def header_pill(im, s, alpha=1.0, kind="muted", x=1765):
    """Label tambahan di kanan atas, di sebelah kiri penomoran adegan."""
    fg, bg = {"muted": (MUTED, WHITE), "red": (RED, RED_BG), "green": (GREEN, GREEN_BG),
              "yellow": (YELLOW, YELLOW_BG)}[kind]
    group(im, alpha, lambda img: pill(img, x, 66, s, font("semi", 28), fg=fg, bg=bg, anchor="r",
                                      outline=fg if kind != "muted" else LINE, padx=16, h=46))


def caption(im, s, alpha, y=992):
    if alpha <= 0.004:
        return

    def fn(img):
        f = font("bold", 38)
        lines = wrap(s, f, 1640)
        lh = 50
        wmax = max(tw(l_, f) for l_ in lines)
        h = lh * len(lines) + 30
        x0 = 960 - wmax / 2 - 34
        y0 = y - h / 2
        rrect(img, (x0, y0 + 4, 1920 - x0, y0 + h + 6), r=22, fill=(20, 40, 30, 18))
        rrect(img, (x0, y0, 1920 - x0, y0 + h), r=22, fill=WHITE, outline=LINE, width=2)
        for i, l_ in enumerate(lines):
            text(img, (960, y0 + 15 + lh * i + lh / 2), l_, f, INK, anchor="mm")

    group(im, alpha, fn)


def chip(im, x, y, s, *, color=BLUE, bg=BLUE_BG, mono=True, anchor="c", h=46):
    f = font("monob" if mono else "bold", 28)
    return pill(im, x, y, s, f, fg=color, bg=bg, anchor=anchor, outline=color, padx=14, h=h)


def status_pill(im, x, y, kind, s=None, anchor="l"):
    """running (hijau, titik), down (abu, silang), starting (kuning)."""
    f = font("semi", 28)
    fg, bg = {"running": (GREEN, GREEN_BG), "down": (MUTED, GREY_BG), "starting": (YELLOW, YELLOW_BG),
              "red": (RED, RED_BG)}[kind]
    s = s or {"running": "running", "down": "tidak terjangkau", "starting": "STARTING", "red": "mati"}[kind]
    box = pill(im, x, y, "     " + s, f, fg=fg, bg=bg, anchor=anchor, outline=fg, padx=14, h=44)
    c = (box[0] + 26, y)
    if kind == "running":
        circle(im, c, 8, fill=GREEN)
    elif kind in ("down", "red"):
        icon_cross(im, c, 16, fg)
    else:
        circle(im, c, 9, outline=YELLOW, width=3)
    return box


# ================= host & node =================
def host_frame(im, box, host, *, down=0.0, hl=0.0, note=None):
    """Bingkai satu mesin fisik. down 0..1 = meredup + garis merah; hl 0..1 = sorot hijau."""
    x0, y0, x1, y1 = box
    fill = mix(HOST_BG, RED_BG, 0.55 * down)
    oc = mix(mix(LINE, GREEN, hl), RED, down)
    rrect(im, box, r=24, fill=fill, outline=oc, width=3 if (hl > 0.5 or down > 0.5) else 2)
    col = mix(INK, MUTED, down)
    icon_server(im, x0 + 26, y0 + 22, 34, mix(GREEN, RED, down))
    text(im, (x0 + 76, y0 + 40), f"host {host}", font("bold", 34), col, anchor="lm")
    text(im, (x1 - 26, y0 + 40), note if note else HOST_IP[host], font("mono", 28),
         RED if (note and down > 0.5) else MUTED, anchor="rm")


def node_card(im, x, y, w, n, *, h=262, state="ok", role_hl=(0.0, 0.0), extra=None, dim=0.0,
              border=None, voter=False, roles=True, port=True):
    """Kartu satu node Kafka (broker + controller).
    state: ok | limbo (hidup tanpa controller) | down. extra(img, x, y, w, h) menggambar isi tambahan.
    roles/port=False untuk kartu ringkas (hanya judul + status)."""
    _, name, host, cport = NODES[n - 1]
    bc = border or {"ok": LINE, "limbo": YELLOW, "down": LINE}[state]
    shadow_card(im, (x, y, x + w, y + h), r=18, border=bc, bw=2 if bc == LINE else 3)
    text(im, (x + 26, y + 36), name, font("monob", 32), INK, anchor="lm")
    text(im, (x + w - 26, y + 36), f"node {n}", font("semi", 28), MUTED, anchor="rm")
    rrect(im, (x + 2, y + 69, x + w - 2, y + 71), r=0, fill=LINE)
    if roles:
        b1 = chip(im, x + 26, y + 112, "broker", color=BLUE, bg=BLUE_BG, anchor="l")
        b2 = chip(im, b1[2] + 12, y + 112, "controller", color=GREEN, bg=GREEN_BG, anchor="l")
        for b, a in zip((b1, b2), role_hl):
            if a > 0.004:
                rrect(im, (b[0] - 6, b[1] - 6, b[2] + 6, b[3] + 6), r=29, outline=mix(LINE, INK, a), width=3)
        if voter:
            chip(im, b2[2] + 12, y + 112, "voter", color=YELLOW, bg=YELLOW_BG, mono=False, anchor="l")
    if port:
        text(im, (x + 26, y + 168), f"controller :{cport}", font("mono", 28), MUTED, anchor="lm")
    if state == "down":
        status_pill(im, x + 26, y + h - 42, "down")
    else:
        status_pill(im, x + 26, y + h - 42, "running")
    if extra:
        extra(im, x, y, w, h)
    if dim > 0.004:
        rrect(im, (x - 2, y - 2, x + w + 4, y + h + 10), r=20, fill=HOST_BG + (int(200 * dim),))
    return (x, y, x + w, y + h)


def mini_node(im, c, n, *, state="ok", s=104):
    """Kotak node kecil berisi nomor (adegan judul & jebakan)."""
    x0, y0 = c[0] - s / 2, c[1] - s / 2
    col = {"ok": (GREEN, WHITE, GREEN), "limbo": (YELLOW_BG, YELLOW, YELLOW), "down": (GREY_BG, GREY, GREY),
           "voter": (GREEN, WHITE, GREEN)}[state]
    rrect(im, (x0 + 2, y0 + 6, x0 + s + 2, y0 + s + 8), r=20, fill=(20, 40, 30, 16))
    rrect(im, (x0, y0, x0 + s, y0 + s), r=20, fill=col[0], outline=col[2], width=3)
    text(im, (c[0], c[1] + 2), str(n), font("xbold", 50), col[1], anchor="mm")
    if state == "down":
        icon_cross(im, (x0 + s - 6, y0 + 6), 20, RED, RED_BG)


# ================= quorum =================
def seat(im, c, r, n, state, pulse=0.0):
    """Kursi voter. state: wait (kosong) | on (memberi suara) | self (hanya memilih diri) | off (mati)."""
    if pulse > 0.004:
        circle(im, c, r + 10 + 18 * pulse, fill=mix(GREEN_BG, BG, pulse))
    if state == "on":
        circle(im, c, r, fill=GREEN, outline=GREEN, width=3)
        text(im, (c[0], c[1] + 2), str(n), font("xbold", int(r * 0.85)), WHITE, anchor="mm")
        icon_check(im, (c[0] + r * 0.72, c[1] - r * 0.72), r * 0.32, WHITE, GREEN)
    elif state == "self":
        circle(im, c, r, fill=YELLOW_BG, outline=YELLOW, width=4)
        text(im, (c[0], c[1] + 2), str(n), font("xbold", int(r * 0.85)), YELLOW, anchor="mm")
    elif state == "off":
        circle(im, c, r, fill=GREY_BG, outline=GREY, width=3)
        text(im, (c[0], c[1] + 2), str(n), font("xbold", int(r * 0.85)), GREY, anchor="mm")
        icon_cross(im, (c[0] + r * 0.72, c[1] - r * 0.72), r * 0.34, RED, RED_BG)
    else:
        circle(im, c, r, fill=WHITE, outline=LINE, width=3)
        text(im, (c[0], c[1] + 2), str(n), font("xbold", int(r * 0.85)), MUTED, anchor="mm")


def vote_meter(im, x, y, votes, *, need=2, total=3, sw=92, sh=40, label=True):
    """Tiga slot suara; garis ambang setelah slot ke-`need`. votes boleh pecahan (animasi)."""
    ok = votes >= need - 1e-6
    col, bgc = (GREEN, GREEN_BG) if ok else (RED, RED_BG)
    gap = 12
    for i in range(total):
        sx = x + i * (sw + gap)
        rrect(im, (sx, y, sx + sw, y + sh), r=10, fill=WHITE, outline=LINE, width=2)
        k = max(0.0, min(1.0, votes - i))
        if k > 0.004:
            rrect(im, (sx + 4, y + 4, sx + 4 + (sw - 8) * k, y + sh - 4), r=7, fill=col)
    tx = x + need * (sw + gap) - gap / 2
    rrect(im, (tx - 2, y - 14, tx + 2, y + sh + 14), r=2, fill=INK)
    wtot = total * (sw + gap) - gap
    if label:
        text(im, (tx, y + sh + 34), "butuh 2", font("semi", 28), INK, anchor="mm")
        v = int(round(votes))
        text(im, (x + wtot + 22, y + sh / 2), f"{v}/{total} suara", font("bold", 32), col, anchor="lm")
    return (x, y, x + wtot, y + sh), bgc


# ================= penghitung & log =================
def counter_row(im, x, y, w, label, sub, value, color, *, k=1.0):
    """Satu baris penghitung: label di kiri, angka besar di kanan (value * k, dibulatkan)."""
    text(im, (x, y - 14), label, font("bold", 32), INK, anchor="lm")
    if sub:
        text(im, (x, y + 24), sub, font("sans", 28), MUTED, anchor="lm")
    v = int(round(value * k))
    text(im, (x + w, y + 4), fmt_id(v), font("xbold", 64), color, anchor="rm")


def log_card(im, box, t, t0, rate, *, title="kafka-1 · cuplikan log (disederhanakan)", alpha_new=1.0):
    """Log yang terus bertambah: baris baru muncul di bawah, yang lama menggulung ke atas."""
    x0, y0, x1, y1 = box
    shadow_card(im, box, r=18, fill=WHITE)
    text(im, (x0 + 24, y0 + 30), title, font("monob", 28), MUTED, anchor="lm")
    rrect(im, (x0 + 2, y0 + 59, x1 - 2, y0 + 61), r=0, fill=LINE)
    if t < t0:
        return
    lh = 40
    area_top, area_bot = y0 + 72, y1 - 14
    nvis = int((area_bot - area_top) // lh)
    pos = (t - t0) * rate
    n = int(pos)
    frac = pos - n
    fm = font("mono", 24)
    fb = font("monob", 24)
    for j in range(nvis + 1):
        idx = n - j
        if idx < 0:
            break
        tag, msg, col = LOG_LINES[idx % len(LOG_LINES)]
        s = min(1.0, frac * 3)          # semua baris naik satu tingkat di sepertiga awal interval
        ly = area_bot - lh / 2 - j * lh + (1 - s) * lh
        if ly < area_top + lh / 2 - 2:
            continue
        a = s if j == 0 else 1.0

        def draw_line(img, ly=ly, tag=tag, msg=msg, col=col):
            tx = x0 + 24
            text(img, (tx, ly), tag, fb, col, anchor="lm")
            text(img, (tx + tw(tag + " ", fb), ly), msg, fm, INK, anchor="lm")
        group(im, a, draw_line)


def bubble(im, x, y, s, *, color=YELLOW, bg=YELLOW_BG, tail="down", f=None, x0=None):
    """Gelembung ucapan; (x, y) = ujung ekor, x0 = tepi kiri kotak (bawaan: 60 px kiri dari ekor)."""
    from gfx import shape
    f = f or font("semi", 28)
    w_ = tw(s, f) + 44
    h = 64
    bx0 = x - 60 if x0 is None else x0
    by1 = y - 18 if tail == "down" else y + 18 + h
    by0 = by1 - h
    rrect(im, (bx0, by0, bx0 + w_, by1), r=20, fill=bg, outline=color, width=2)
    if tail == "down":
        tri = [(x - 14, by1 - 1), (x, y), (x + 14, by1 - 1)]
    else:
        tri = [(x - 14, by0 + 1), (x, y), (x + 14, by0 + 1)]
    xs = [p[0] for p in tri]
    ys = [p[1] for p in tri]
    shape(im, (min(xs) - 2, min(ys) - 2, max(xs) + 2, max(ys) + 2), bg,
          lambda d, S: d.polygon([S(p) for p in tri], fill=255))
    text(im, (bx0 + 22, (by0 + by1) / 2), s, f, color, anchor="lm")


def spinner(im, c, r, t, color=YELLOW, width=5):
    """Busur berputar (menunggu)."""
    a0 = t * 4.0
    pts = [(c[0] + math.cos(a0 + i * 0.12) * r, c[1] + math.sin(a0 + i * 0.12) * r) for i in range(36)]
    line(im, pts, color, width)


def hl_color(kind):
    return {"blue": (BLUE_BG, BLUE), "green": (GREEN_BG, GREEN), "yellow": (YELLOW_BG, YELLOW),
            "red": (RED_BG, RED)}[kind]
