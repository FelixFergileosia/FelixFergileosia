"""Primitif gambar untuk video (Pillow). Semua bentuk lengkung/diagonal digambar dengan
supersampling supaya halus pada 1080p."""
import math
from functools import lru_cache

from PIL import Image, ImageChops, ImageDraw, ImageFont

W, H = 1920, 1080

# ---- palet (dari spesifikasi) ----
BG = (0xF5, 0xF7, 0xF4)
INK = (0x17, 0x20, 0x1C)
GREEN = (0x07, 0x5E, 0x45)
RED = (0x9C, 0x2D, 0x24)
YELLOW = (0x9B, 0x65, 0x00)
BLUE = (0x07, 0x5E, 0x91)
# turunan
MUTED = (0x5A, 0x66, 0x60)
LINE = (0xD3, 0xDB, 0xD5)
WHITE = (0xFF, 0xFF, 0xFF)
GREEN_BG = (0xDD, 0xEF, 0xE6)
RED_BG = (0xF7, 0xE1, 0xDE)
YELLOW_BG = (0xFA, 0xEC, 0xCB)
BLUE_BG = (0xDC, 0xEB, 0xF6)
ICE_BG = (0xE6, 0xF1, 0xF8)

# ---- font ----
_F = {
    "sans": "/usr/share/fonts/opentype/inter/Inter-Medium.otf",
    "semi": "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf",
    "bold": "/usr/share/fonts/opentype/inter/Inter-Bold.otf",
    "xbold": "/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf",
    "mono": "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    "monob": "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
}


@lru_cache(None)
def font(kind, size):
    return ImageFont.truetype(_F[kind], size)


def tw(s, f):
    return f.getlength(s)


# ---- waktu & easing ----
def clamp(x, a=0.0, b=1.0):
    return a if x < a else b if x > b else x


def ease(x):
    x = clamp(x)
    return x * x * x * (x * (x * 6 - 15) + 10)


def prog(t, t0, d=0.5):
    """0..1 ter-ease, mulai di t0 selama d detik."""
    if d <= 0:
        return 1.0 if t >= t0 else 0.0
    return ease((t - t0) / d)


def window(t, t0, t1, fade=0.35):
    """Naik di t0, turun di t1."""
    return min(prog(t, t0, fade), 1 - prog(t, t1, fade))


def lerp(a, b, k):
    return a + (b - a) * k


def mix(c1, c2, k):
    return tuple(int(round(lerp(a, b, k))) for a, b in zip(c1, c2))


# ---- komposisi ----
def new_frame():
    return Image.new("RGBA", (W, H), BG + (255,))


def group(im, alpha, fn):
    """Gambar fn(img) dengan opasitas alpha (0..1)."""
    if alpha <= 0.004:
        return
    if alpha >= 0.996:
        fn(im)
        return
    tmp = Image.new("RGBA", im.size, (0, 0, 0, 0))
    fn(tmp)
    bb = tmp.getbbox()
    if not bb:
        return
    crop = tmp.crop(bb)
    a = crop.getchannel("A").point(lambda v: int(v * alpha))
    crop.putalpha(a)
    im.alpha_composite(crop, (bb[0], bb[1]))


def _paste_color(im, x, y, mask, color):
    if len(color) == 4:
        mask = mask.point(lambda v: v * color[3] // 255)
        color = color[:3]
    solid = Image.new("RGBA", mask.size, color + (255,))
    solid.putalpha(mask)
    im.alpha_composite(solid, (int(x), int(y)))


@lru_cache(512)
def _rr_mask(w, h, r, ss=4):
    m = Image.new("L", (w * ss, h * ss), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w * ss - 1, h * ss - 1), radius=r * ss, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def rrect(im, box, r=16, fill=None, outline=None, width=2):
    x0, y0, x1, y1 = [int(round(v)) for v in box]
    w, h = x1 - x0, y1 - y0
    if w <= 0 or h <= 0:
        return
    r = min(r, w // 2, h // 2)
    if outline is not None and width > 0:
        outer = _rr_mask(w, h, r)
        if fill is not None:
            _paste_color(im, x0, y0, outer, outline)
            iw, ih = w - 2 * width, h - 2 * width
            if iw > 0 and ih > 0:
                _paste_color(im, x0 + width, y0 + width, _rr_mask(iw, ih, max(r - width, 0)), fill)
        else:
            inner = Image.new("L", (w, h), 0)
            iw, ih = w - 2 * width, h - 2 * width
            if iw > 0 and ih > 0:
                inner.paste(_rr_mask(iw, ih, max(r - width, 0)), (width, width))
            _paste_color(im, x0, y0, ImageChops.subtract(outer, inner), outline)
    elif fill is not None:
        _paste_color(im, x0, y0, _rr_mask(w, h, r), fill)


def shape(im, bbox, color, drawfn, ss=4):
    """Gambar bentuk bebas pada mask supersampled. drawfn(draw, S) memakai koordinat absolut
    yang sudah dikonversi lewat S((x, y)) dan skala lebar lewat S.k."""
    x0, y0, x1, y1 = [int(math.floor(v)) for v in bbox]
    x1 += 1
    y1 += 1
    w, h = x1 - x0, y1 - y0
    if w <= 0 or h <= 0:
        return
    m = Image.new("L", (w * ss, h * ss), 0)
    d = ImageDraw.Draw(m)

    class _S:
        k = ss

        def __call__(self, p):
            return ((p[0] - x0) * ss, (p[1] - y0) * ss)

    drawfn(d, _S())
    _paste_color(im, x0, y0, m.resize((w, h), Image.LANCZOS), color)


def line(im, pts, color, width=4):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    pad = width + 2

    def fn(d, S):
        d.line([S(p) for p in pts], fill=255, width=int(width * S.k), joint="curve")
        for p in (pts[0], pts[-1]):
            c = S(p)
            r = width * S.k / 2
            d.ellipse((c[0] - r, c[1] - r, c[0] + r, c[1] + r), fill=255)

    shape(im, (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad), color, fn)


def circle(im, c, r, fill=None, outline=None, width=3):
    def fn(d, S):
        p = S(c)
        R = r * S.k
        d.ellipse((p[0] - R, p[1] - R, p[0] + R, p[1] + R), fill=255)
        if fill is None and outline is not None:
            R2 = (r - width) * S.k
            d.ellipse((p[0] - R2, p[1] - R2, p[0] + R2, p[1] + R2), fill=0)

    bb = (c[0] - r - 2, c[1] - r - 2, c[0] + r + 2, c[1] + r + 2)
    if fill is not None and outline is not None:
        shape(im, bb, outline, fn)
        circle(im, c, r - width, fill=fill)
    else:
        shape(im, bb, fill if fill is not None else outline, fn)


def _poly_point(pts, k):
    """Titik pada polyline di fraksi panjang k; kembalikan (titik, sudut, potongan-polyline)."""
    segs = [(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
    lens = [math.dist(a, b) for a, b in segs]
    total = sum(lens) or 1
    target = total * clamp(k)
    acc = 0
    out = [pts[0]]
    for (a, b), L in zip(segs, lens):
        if acc + L >= target:
            f = (target - acc) / L if L else 0
            p = (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)
            out.append(p)
            return p, math.atan2(b[1] - a[1], b[0] - a[0]), out
        acc += L
        out.append(b)
    a, b = segs[-1]
    return pts[-1], math.atan2(b[1] - a[1], b[0] - a[0]), out


def arrow(im, pts, color, width=5, head=20, k=1.0, dashed=False):
    """Panah sepanjang polyline pts, tergambar sampai fraksi k (untuk animasi tumbuh)."""
    if k <= 0.001:
        return
    tip, ang, part = _poly_point(pts, k)
    # mundurkan ujung garis agar tidak menembus kepala panah
    back = (tip[0] - math.cos(ang) * head * 0.7, tip[1] - math.sin(ang) * head * 0.7)
    body = part[:-1] + [back]
    if dashed:
        _dashed(im, body, color, width)
    else:
        line(im, body, color, width)
    a1 = ang + math.radians(152)
    a2 = ang - math.radians(152)
    p1 = (tip[0] + math.cos(a1) * head, tip[1] + math.sin(a1) * head)
    p2 = (tip[0] + math.cos(a2) * head, tip[1] + math.sin(a2) * head)
    tri = [tip, p1, p2]
    xs = [p[0] for p in tri]
    ys = [p[1] for p in tri]
    shape(im, (min(xs) - 2, min(ys) - 2, max(xs) + 2, max(ys) + 2), color,
          lambda d, S: d.polygon([S(p) for p in tri], fill=255))


def _dashed(im, pts, color, width, dash=14, gap=10):
    for a, b in zip(pts, pts[1:]):
        L = math.dist(a, b)
        n = 0.0
        while n < L:
            e = min(n + dash, L)
            p = (a[0] + (b[0] - a[0]) * n / L, a[1] + (b[1] - a[1]) * n / L)
            q = (a[0] + (b[0] - a[0]) * e / L, a[1] + (b[1] - a[1]) * e / L)
            line(im, [p, q], color, width)
            n += dash + gap


def text(im, xy, s, f, fill=INK, anchor="la"):
    ImageDraw.Draw(im).text(xy, s, font=f, fill=fill, anchor=anchor)


def wrap(s, f, maxw):
    words = s.split(" ")
    lines, cur = [], ""
    for w_ in words:
        cand = (cur + " " + w_).strip()
        if tw(cand, f) <= maxw or not cur:
            cur = cand
        else:
            lines.append(cur)
            cur = w_
    if cur:
        lines.append(cur)
    return lines


def pill(im, x, y, s, f, fg=WHITE, bg=GREEN, padx=18, h=None, anchor="l", outline=None, ow=2):
    """Label membulat. anchor: 'l' (x=kiri), 'c' (x=tengah), 'r' (x=kanan); y = tengah vertikal."""
    w_ = tw(s, f) + 2 * padx
    h = h or int(f.size * 1.6)
    if anchor == "c":
        x0 = x - w_ / 2
    elif anchor == "r":
        x0 = x - w_
    else:
        x0 = x
    box = (x0, y - h / 2, x0 + w_, y + h / 2)
    rrect(im, box, r=h // 2, fill=bg, outline=outline, width=ow)
    text(im, (x0 + w_ / 2, y + 1), s, f, fill=fg, anchor="mm")
    return box


def shadow_card(im, box, r=18, fill=WHITE, border=LINE, bw=2, lift=1.0):
    x0, y0, x1, y1 = box
    rrect(im, (x0 + 2, y0 + 6 * lift, x1 + 2, y1 + 8 * lift), r=r, fill=(20, 40, 30, int(16 * lift)))
    rrect(im, box, r=r, fill=fill, outline=border, width=bw)


# ---- ikon ----
def icon_check(im, c, r, color=GREEN, bg=None):
    if bg is not None:
        circle(im, c, r, fill=bg)
    pts = [(c[0] - r * 0.45, c[1] + r * 0.02), (c[0] - r * 0.12, c[1] + r * 0.35), (c[0] + r * 0.48, c[1] - r * 0.33)]
    line(im, pts, color, max(3, int(r * 0.22)))


def icon_cross(im, c, r, color=RED, bg=None):
    if bg is not None:
        circle(im, c, r, fill=bg)
    k = r * 0.38
    w_ = max(3, int(r * 0.2))
    line(im, [(c[0] - k, c[1] - k), (c[0] + k, c[1] + k)], color, w_)
    line(im, [(c[0] - k, c[1] + k), (c[0] + k, c[1] - k)], color, w_)


def icon_signal(im, x, y, h, color, crossed=False, n=4):
    """Bar sinyal; (x,y) = kiri-bawah."""
    bw = h * 0.18
    gap = h * 0.08
    for i in range(n):
        bh = h * (i + 1) / n
        x0 = x + i * (bw + gap)
        rrect(im, (x0, y - bh, x0 + bw, y), r=2, fill=color)
    if crossed:
        wtot = n * (bw + gap)
        line(im, [(x - 6, y - h - 4), (x + wtot + 4, y + 6)], RED, 6)


def icon_retry(im, c, r, angle, color, width=6):
    """Panah melingkar (ikon kirim ulang) diputar sebesar angle (radian)."""
    pts = []
    for i in range(0, 41):
        a = angle + math.radians(30 + i * 7.5)
        pts.append((c[0] + math.cos(a) * r, c[1] + math.sin(a) * r))
    line(im, pts, color, width)
    end = pts[-1]
    a_end = angle + math.radians(30 + 40 * 7.5)
    tang = a_end + math.pi / 2
    head = r * 0.55
    tip = (end[0] + math.cos(tang) * head * 0.6, end[1] + math.sin(tang) * head * 0.6)
    p1 = (tip[0] + math.cos(tang + math.radians(145)) * head, tip[1] + math.sin(tang + math.radians(145)) * head)
    p2 = (tip[0] + math.cos(tang - math.radians(145)) * head, tip[1] + math.sin(tang - math.radians(145)) * head)
    tri = [tip, p1, p2]
    xs = [p[0] for p in tri]
    ys = [p[1] for p in tri]
    shape(im, (min(xs) - 2, min(ys) - 2, max(xs) + 2, max(ys) + 2), color,
          lambda d, S: d.polygon([S(p) for p in tri], fill=255))


def icon_server(im, x, y, w_, color):
    """Ikon server bertumpuk 3; (x,y) kiri-atas."""
    h = w_ * 0.3
    for i in range(3):
        yy = y + i * (h + 6)
        rrect(im, (x, yy, x + w_, yy + h), r=6, fill=color)
        circle(im, (x + w_ - h * 0.55, yy + h / 2), h * 0.16, fill=WHITE)
        rrect(im, (x + h * 0.4, yy + h * 0.42, x + w_ * 0.5, yy + h * 0.58), r=2, fill=WHITE)


def icon_snow(im, c, r, color, width=4):
    for i in range(3):
        a = math.radians(90 + i * 60)
        p = (c[0] + math.cos(a) * r, c[1] + math.sin(a) * r)
        q = (c[0] - math.cos(a) * r, c[1] - math.sin(a) * r)
        line(im, [p, q], color, width)
        for s in (1, -1):
            e = (c[0] + math.cos(a) * r * 0.6 * s, c[1] + math.sin(a) * r * 0.6 * s)
            for da in (35, -35):
                b = a + math.radians(da) + (math.pi if s < 0 else 0)
                line(im, [e, (e[0] + math.cos(b) * r * 0.32, e[1] + math.sin(b) * r * 0.32)], color, width - 1)


def icon_magnifier(im, c, r, color, width=6):
    circle(im, c, r, outline=color, width=width)
    a = math.radians(45)
    p = (c[0] + math.cos(a) * r, c[1] + math.sin(a) * r)
    line(im, [p, (p[0] + r * 0.8, p[1] + r * 0.8)], color, width + 2)


def icon_trash(im, x, y, s, color):
    rrect(im, (x + s * 0.1, y, x + s * 0.9, y + s * 0.12), r=3, fill=color)
    rrect(im, (x + s * 0.38, y - s * 0.1, x + s * 0.62, y + s * 0.02), r=3, fill=color)
    rrect(im, (x + s * 0.18, y + s * 0.18, x + s * 0.82, y + s), r=6, fill=color)
