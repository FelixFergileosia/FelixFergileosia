"""Naskah narasi per adegan.

Setiap adegan dipecah per kalimat ("segmen"). Satu segmen = satu klip TTS, sehingga waktu
mulai tiap kalimat diketahui pasti dan animasi bisa ditambatkan ke sana.

`text` adalah teks tampil (dipakai di subtitle .srt): angka ditulis sebagai angka. Teks yang
dikirim ke mesin suara dibuat otomatis: istilah asing dieja ulang lewat TTS_RESPELL supaya
diucapkan wajar oleh suara bahasa Indonesia (mis. "KRaft" -> "kei raft"), lalu angka diubah
menjadi kata (mis. "7.214" -> "tujuh ribu dua ratus empat belas", "19.17" -> jam).
"""
import re

# Ejaan ulang khusus mesin suara. Urutan penting (frasa panjang dulu).
TTS_RESPELL = [
    ("min.insync.replicas", "min insing replikas"),
    ("replication factor", "replikesyen faktor"),
    ("Replication factor", "Replikesyen faktor"),
    ("Consumer group", "Konsyumer grup"),
    ("consumer group", "konsyumer grup"),
    ("acks=all", "eks ol"),
    ("pre-vote", "pri vout"),
    ("kafka-1", "kafka satu"),
    ("KRaft", "kei raft"),
    ("Kafka", "kafka"),
    ("controller", "kontroler"),
    ("broker", "broker"),
    ("quorum", "kuorum"),
    ("voter", "voter"),
    ("ISR", "ai es ar"),
    ("producer", "prodyuser"),
    ("offset", "ofset"),
    ("running", "raning"),
    ("STARTING", "starting"),
    ("Candidate", "kendidet"),
    ("retry", "ritrai"),
    ("Node", "Noud"),
    ("node", "noud"),
    ("host", "houst"),
    ("rsync", "ar sing"),
    # tambahan (bukan dari daftar awal) untuk istilah lain di naskah
    ("IO stall", "ai o stol"),
    ("WIB", "we i be"),
    ("reboot", "rebut"),
    ("restart", "ristarrt"),
    ("timeout", "taimaut"),
    ("Produce", "Prodyus"),
    ("rebalance", "ribelens"),
    ("commit", "komit"),
    ("topic", "topik"),
    ("container", "kontainer"),
    ("outage", "autej"),
    ("error", "eror"),
    ("leader", "lider"),
    ("primary", "praimeri"),
    ("standby", "stendbai"),
    ("freeze", "fris"),
    ("Cluster", "Klaster"),
    ("cluster", "klaster"),
    ("9092", "sembilan nol sembilan dua"),
]

_SAT = ["nol", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan",
        "sepuluh", "sebelas"]


def terbilang(n: int) -> str:
    """Angka -> kata bahasa Indonesia (0 .. 999.999.999)."""
    def tail(r, f):
        return f + (" " + terbilang(r) if r else "")
    if n < 12:
        return _SAT[n]
    if n < 20:
        return terbilang(n - 10) + " belas"
    if n < 100:
        return tail(n % 10, terbilang(n // 10) + " puluh")
    if n < 200:
        return tail(n - 100, "seratus")
    if n < 1000:
        return tail(n % 100, terbilang(n // 100) + " ratus")
    if n < 2000:
        return tail(n - 1000, "seribu")
    if n < 1_000_000:
        return tail(n % 1000, terbilang(n // 1000) + " ribu")
    return tail(n % 1_000_000, terbilang(n // 1_000_000) + " juta")


def spoken_numbers(text: str) -> str:
    """Ganti angka dengan kata: jam (19.17), ribuan bertitik (69.458), lalu bilangan bulat."""
    text = re.sub(r"\b(\d{1,2})\.(\d{2})\b(?!\.\d)",
                  lambda m: f"{terbilang(int(m.group(1)))} {terbilang(int(m.group(2)))}", text)
    text = re.sub(r"\b\d{1,3}(?:\.\d{3})+\b", lambda m: terbilang(int(m.group(0).replace(".", ""))), text)
    return re.sub(r"\d+", lambda m: terbilang(int(m.group(0))), text)


def to_tts(text: str) -> str:
    for a, b in TTS_RESPELL:
        text = text.replace(a, b)
    return spoken_numbers(text)


SCENES = [
    {
        "id": 1,
        "title": "Judul",
        "segments": [
            ("intro", "Kafka di host 177 sehat."),
            ("q1", "Kenapa ikut lumpuh saat host 181 mati?"),
            ("motto", "Karena Kafka tidak mati, ia kalah suara."),
        ],
    },
    {
        "id": 2,
        "title": "Topologi",
        "segments": [
            ("nodes", "Ada 3 node, masing-masing broker sekaligus controller."),
            ("place", "Node 1 di host 177, node 2 dan 3 di host 181."),
            ("rf", "Setiap data punya 3 salinan, dan tulisan butuh minimal 2 salinan sinkron."),
        ],
    },
    {
        "id": 3,
        "title": "Aturan mayoritas",
        "segments": [
            ("need", "Ketiga node adalah voter, dan controller butuh mayoritas: 2 dari 3 suara."),
            ("noctl", "Tanpa controller, leader tidak bisa dipindah."),
            ("c177", "Kalau 177 mati, masih ada 2 suara."),
            ("c181", "Kalau 181 mati, tinggal 1 suara: lumpuh."),
            ("spof", "Jadi 181 adalah titik gagal tunggal."),
        ],
    },
    {
        "id": 4,
        "title": "Malam 29 Oktober",
        "segments": [
            ("reboot", "Pukul 19.17, host 181 mengalami reboot."),
            ("alive", "kafka-1 tetap hidup, tanpa restart."),
            ("ask", "Ia terus bertanya: boleh saya mencalonkan diri?"),
            ("count", "7.214 kali pre-vote, 80 kali menjadi Candidate."),
            ("fail", "Selalu gagal: hanya 1 suara dari 3."),
            ("logs", "Dalam 3 jam, lognya mencapai 69.458 baris."),
        ],
    },
    {
        "id": 5,
        "title": "Apa yang berhenti",
        "segments": [
            ("produce", "Produce acks=all ditolak, karena hanya 1 replika yang hidup."),
            ("group", "Consumer group tidak bisa commit offset: 4.144 kali timeout."),
            ("running", "Tapi container tetap running."),
            ("neq", "Ingat: running tidak sama dengan melayani."),
        ],
    },
    {
        "id": 6,
        "title": "Pulih sendiri",
        "segments": [
            ("back", "Pukul 22.25, host 181 kembali."),
            ("elect", "Controller terpilih dalam hitungan detik, tanpa restart."),
            ("safe", "Data aman: tulisan ditolak, bukan dibuang."),
            ("app", "Tapi aplikasi wajib menyimpan pesan yang ditolak, lalu retry."),
            ("lost", "Kalau tidak, pesan selama outage bisa hilang."),
        ],
    },
    {
        "id": 7,
        "title": "Jebakan",
        "segments": [
            ("move", "Memindah voter ke 177 tidak menolong."),
            ("move2", "Dengan 2 host, mayoritas selalu di satu host, jadi titik gagal hanya pindah."),
            ("restart", "Restart kafka-1 juga tidak menolong: ia akan tertahan di STARTING."),
        ],
    },
    {
        "id": 8,
        "title": "Ringkasan",
        "segments": [
            ("p1", "Jadi, kafka-1 tidak rusak, hanya mati suri."),
            ("p2", "Akarnya desain: 2 dari 3 voter ada di host 181."),
            ("o1", "Pilihan pertama: voter ketiga di host independen, bukan host 51."),
            ("o2", "Kedua: cluster yang utuh di 181, dan 177 sebagai standby."),
            ("o3", "Ketiga, paling murah: perbaiki freeze malam di 181."),
        ],
    },
]
