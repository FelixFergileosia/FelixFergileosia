"""Render video: frame Pillow -> ffmpeg (H.264), gabung audio narasi, normalisasi loudness,
dan tulis subtitle .srt.

Pemakaian:
  python3 src/render.py stills          # 1 PNG dari tengah tiap adegan -> build/check/
  python3 src/render.py still 5 12.3    # 1 PNG adegan 5 pada detik 12.3
  python3 src/render.py all             # render penuh -> out/
"""
import json
import subprocess
import sys
import wave
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from components import Timing  # noqa: E402
from gfx import new_frame  # noqa: E402
from scenes import SCENE_FUNCS  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
OUT = ROOT / "out"
FPS = 30
NAME = "kafka-quorum-181-explainer"


def frames_of(sid):
    return int(round(Timing(sid).dur * FPS))


def draw(sid, t, T=None):
    T = T or Timing(sid)
    im = new_frame()
    SCENE_FUNCS[sid](im, t, T)
    return im.convert("RGB")


def render_scene(sid):
    T = Timing(sid)
    n = frames_of(sid)
    out = BUILD / f"video/scene_{sid:02d}.mp4"
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1920x1080",
           "-r", str(FPS), "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
           "-pix_fmt", "yuv420p", "-r", str(FPS), str(out)]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(draw(sid, i / FPS, T).tobytes())
    p.stdin.close()
    p.wait()
    return sid, n


def build_audio():
    """Gabung audio per adegan (dipas tepat ke jumlah frame), lalu loudnorm 2-pass -> 48 kHz stereo."""
    parts = []
    for sid in SCENE_FUNCS:
        with wave.open(str(BUILD / f"audio/scene_{sid:02d}.wav")) as w:
            sr = w.getframerate()
            a = np.frombuffer(w.readframes(w.getnframes()), np.int16)
        need = int(round(frames_of(sid) / FPS * sr))
        a = a[:need] if len(a) >= need else np.concatenate([a, np.zeros(need - len(a), np.int16)])
        parts.append(a)
    full = np.concatenate(parts)
    raw = BUILD / "narration_raw.wav"
    with wave.open(str(raw), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(full.tobytes())
    # pass 1: ukur
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(raw), "-af",
                        "loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True)
    js = r.stderr[r.stderr.rindex("{"): r.stderr.rindex("}") + 1]
    m = json.loads(js)
    af = (f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
          f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true,"
          f"aresample=48000")
    norm = BUILD / "narration_48k.wav"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-af", af, "-ac", "2", "-ar", "48000", str(norm)],
                   check=True)
    return norm


def srt_time(x):
    ms = int(round(x * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def wrap2(s, n=46):
    words, lines, cur = s.split(), [], ""
    for w_ in words:
        if len(cur) + len(w_) + 1 > n and cur:
            lines.append(cur)
            cur = w_
        else:
            cur = (cur + " " + w_).strip()
    lines.append(cur)
    return "\n".join(lines)


def build_srt():
    cues = []
    offset = 0.0
    for sid in SCENE_FUNCS:
        T = Timing(sid)
        for key, sg in T.seg.items():
            txt = sg["text"]
            chunks = [txt]
            if len(txt) > 88:
                # pecah di tanda baca terdekat ke tengah
                cands = [i for i, c in enumerate(txt) if c in ",:" and 25 < i < len(txt) - 20]
                if cands:
                    mid = min(cands, key=lambda i: abs(i - len(txt) / 2))
                    chunks = [txt[: mid + 1].strip(), txt[mid + 1:].strip()]
            starts = [sg["start"]]
            if len(chunks) == 2:
                starts.append(T.w(key, chunks[1][:12]))
            ends = starts[1:] + [sg["end"] + 0.25]
            for c, a, b in zip(chunks, starts, ends):
                cues.append((offset + a - 0.05, offset + b, c))
        offset += frames_of(sid) / FPS
    lines = []
    for i, (a, b, c) in enumerate(cues, 1):
        lines += [str(i), f"{srt_time(a)} --> {srt_time(b)}", wrap2(c), ""]
    path = OUT / f"{NAME}.srt"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode == "stills":
        d = BUILD / "check"
        d.mkdir(parents=True, exist_ok=True)
        for sid in SCENE_FUNCS:
            T = Timing(sid)
            p = d / f"scene_{sid:02d}_mid.png"
            draw(sid, T.dur / 2, T).save(p)
            print(p)
        return
    if mode == "still":
        sid, t = int(sys.argv[2]), float(sys.argv[3])
        d = BUILD / "check"
        d.mkdir(parents=True, exist_ok=True)
        p = d / f"scene_{sid:02d}_t{t:05.1f}.png"
        draw(sid, t).save(p)
        print(p)
        return
    OUT.mkdir(exist_ok=True)
    only = [int(x) for x in sys.argv[2:]] or list(SCENE_FUNCS)
    with ProcessPoolExecutor(max_workers=4) as ex:
        for sid, n in ex.map(render_scene, only):
            print(f"adegan {sid}: {n} frame")
    lst = BUILD / "video/list.txt"
    lst.write_text("".join(f"file 'scene_{sid:02d}.mp4'\n" for sid in SCENE_FUNCS))
    silent = BUILD / "video/all_silent.mp4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy",
                    str(silent)], check=True)
    audio = build_audio()
    final = OUT / f"{NAME}.mp4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(silent), "-i", str(audio), "-map", "0:v", "-map", "1:a",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2", "-shortest",
                    "-movflags", "+faststart", str(final)], check=True)
    srt = build_srt()
    print(final)
    print(srt)


if __name__ == "__main__":
    main()
