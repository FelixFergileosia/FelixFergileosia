"""Delapan adegan. Setiap fungsi menggambar satu frame pada waktu t (detik, relatif adegan).
Semua isyarat waktu diambil dari narasi lewat Timing (T.s = awal kalimat, T.w = awal frasa)."""
import math

from components import (GROUPS, N_CANDIDATE, N_GROUP_TIMEOUT, N_LOGLINES, N_PREVOTE, bubble, caption,
                        chip, chrome, counter_row, fmt_id, header_pill, host_frame, log_card, mini_node, node_card, seat, spinner, status_pill,
                        vote_meter)
from gfx import (BG, BLUE, BLUE_BG, GREEN, GREEN_BG, INK, LINE, MUTED, RED, RED_BG, WHITE, YELLOW,
                 YELLOW_BG, arrow, circle, clamp, ease, font, group, icon_check, icon_cross,
                 icon_retry, lerp, pill, prog, rrect, shadow_card, text, tw, window)

# ---------- teks kaya (campuran sans & mono) dengan word-wrap ----------


def rich(im, x, y, parts, maxw, lh, align="l"):
    """parts: list (teks, font, warna). Kata dibungkus per spasi. Mengembalikan tinggi total."""
    words = []
    for s, f, c in parts:
        for i, w_ in enumerate(s.split(" ")):
            if w_ == "":
                continue
            words.append((w_, f, c))
    lines, cur, cw = [], [], 0
    for w_, f, c in words:
        sp = min(tw(" ", f), tw(" ", cur[-1][1])) if cur else 0
        ww = tw(w_, f)
        if cur and cw + sp + ww > maxw:
            lines.append((cur, cw))
            cur, cw = [], 0
            sp = 0
        cur.append((w_, f, c, sp))
        cw += sp + ww
    if cur:
        lines.append((cur, cw))
    for li, (ws, wtot) in enumerate(lines):
        cx = x - wtot / 2 if align == "c" else x
        cy = y + li * lh + lh / 2
        for w_, f, c, sp in ws:
            cx += sp
            text(im, (cx, cy), w_, f, c, anchor="lm")
            cx += tw(w_, f)
    return len(lines) * lh


def fade_scene(im, t, dur):
    a = max(1 - prog(t, 0, 0.3), prog(t, dur - 0.25, 0.25))
    if a > 0.004:
        from PIL import Image
        ov = Image.new("RGBA", im.size, BG + (int(255 * a),))
        im.alpha_composite(ov)


def slide(t, t0, d=0.5, dist=30):
    k = prog(t, t0, d)
    return k, (1 - k) * dist


def packet(im, pts, k, label="data", color=BLUE, bg=BLUE_BG):
    """Paket (chip) yang bergerak sepanjang garis lurus pts[0]->pts[-1] pada fraksi k."""
    if k <= 0 or k >= 1:
        return
    p = (lerp(pts[0][0], pts[-1][0], ease(k)), lerp(pts[0][1], pts[-1][1], ease(k)))
    a = min(1, k * 6, (1 - k) * 6)
    group(im, a, lambda img: chip(img, p[0], p[1], label, color=color, bg=bg))


def count_up(t, t0, d=1.4):
    """0..1 untuk penghitung: mulai pelan, selesai tepat t0 + d."""
    x = clamp((t - t0) / d)
    return 1 - (1 - x) ** 3


# =====================================================================
# Adegan 1 — Judul
# =====================================================================
def scene1(im, t, T):
    chrome(im, 1, "")
    k, dy = slide(t, 0.1, 0.7, 24)
    group(im, k, lambda img: text(img, (960, 236 + dy), "Apache Kafka 4.1.2 · mode KRaft · 3 node di 2 host",
                                  font("semi", 34), GREEN, anchor="mm"))
    k2, dy2 = slide(t, 0.3, 0.8, 30)

    def title(img):
        f = font("xbold", 76)
        text(img, (960, 340 + dy2), "Kafka di 177 sehat,", f, INK, anchor="mm")
        text(img, (960, 435 + dy2), "kenapa ikut lumpuh saat 181 mati?", f, INK, anchor="mm")
    group(im, k2, title)
    kk = prog(t, 0.6, 0.8)
    if kk > 0:
        rrect(im, (960 - 160 * kk, 506, 960 + 160 * kk, 512), r=3, fill=GREEN)
    k3, dy3 = slide(t, T.s("motto") - 0.1, 0.6, 20)
    group(im, k3, lambda img: text(img, (960, 586 + dy3), "Kafka tidak mati, ia kalah suara.",
                                   font("bold", 50), GREEN, anchor="mm"))

    # ilustrasi: 3 node di 2 host; 181 mati, node 1 tinggal sendiri
    t_dead = T.w("q1", "host 181") + 0.2
    t_alone = T.w("motto", "kalah suara") - 0.1
    kd = prog(t, t_dead, 0.5)
    kill = prog(t, t_dead + 0.3, 0.4)
    ki = prog(t, T.s("intro") - 0.1, 0.6)

    def illo(img):
        host_frame(img, (500, 704, 800, 950), "177", note=" ")
        host_frame(img, (860, 704, 1420, 950), "181", down=kd, note=" ")
        st1 = "limbo" if t >= t_alone else "ok"
        mini_node(img, (650, 840), 1, state=st1)
        for n, x in ((2, 1010), (3, 1270)):
            mini_node(img, (x, 840), n, state="down" if kill > 0.5 else "ok")
        ka = prog(t, t_alone, 0.4)
        if ka > 0:
            group(img, ka, lambda im2: pill(im2, 650, 680, "1/3 suara", font("bold", 30), fg=YELLOW,
                                            bg=YELLOW_BG, anchor="c", outline=YELLOW, padx=18, h=50))
        if kill > 0:
            group(img, kill, lambda im2: pill(im2, 1140, 680, "mati", font("bold", 30), fg=RED, bg=RED_BG,
                                              anchor="c", outline=RED, padx=18, h=50))
    group(im, ki, illo)
    kf = prog(t, 0.8, 0.8)
    group(im, kf, lambda img: text(img, (960, 1022), "Berdasarkan log & metrik nyata 28–30 Oktober 2026",
                                   font("sans", 28), MUTED, anchor="mm"))
    fade_scene(im, t, T.dur)


# =====================================================================
# Adegan 2 — Topologi
# =====================================================================
H177 = (60, 140, 700, 600)
H181 = (760, 140, 1860, 600)
CARD_Y = 230
CARDS = {1: (100, 560), 2: (800, 500), 3: (1320, 500)}   # x, lebar


def replica_extra(k, sync=None):
    """Isi tambahan kartu node: satu salinan data (muncul dengan fraksi k)."""
    def fn(img, x, y, w, h):
        if k <= 0.004:
            return

        def d(im2):
            c = sync is not None and sync > 0.5
            bx = x + w - 26
            box = pill(im2, bx, y + h - 42, "salinan data", font("semi", 28), fg=GREEN if c else BLUE,
                       bg=GREEN_BG if c else BLUE_BG, anchor="r", outline=GREEN if c else BLUE, padx=14, h=44)
            if c:
                icon_check(im2, (box[0] - 22, y + h - 42), 14, GREEN)
        group(img, k, d)
    return fn


def scene2(im, t, T):
    chrome(im, 2, "Topologi: 3 node di 2 host")
    header_pill(im, "Apache Kafka 4.1.2 · KRaft", prog(t, 0.2, 0.5))
    t_nodes = T.s("nodes")
    t_b = T.w("nodes", "broker")
    t_c = T.w("nodes", "controller")
    t_h177 = T.w("place", "host 177")
    t_h181 = T.w("place", "host 181")
    t_rf = T.w("rf", "3 salinan")
    t_mis = T.w("rf", "tulisan butuh")

    kh = prog(t, 0.1, 0.5)
    group(im, kh, lambda img: host_frame(img, H177, "177", hl=window(t, t_h177 - 0.1, t_h177 + 1.6)))
    group(im, kh, lambda img: host_frame(img, H181, "181", hl=window(t, t_h181 - 0.1, t_h181 + 1.6)))
    for n, (x, w) in CARDS.items():
        kc, dyc = slide(t, t_nodes + 0.1 + (n - 1) * 0.25, 0.5, 30)
        rh = (window(t, t_b - 0.1, t_c + 0.4, 0.25), window(t, t_c - 0.1, t_c + 1.4, 0.25))
        ex = replica_extra(prog(t, t_rf - 0.1 + (n - 1) * 0.2, 0.4))
        group(im, kc, lambda img, n=n, x=x, w=w, dyc=dyc, rh=rh, ex=ex:
              node_card(img, x, CARD_Y + dyc, w, n, h=330, role_hl=rh, extra=ex))

    # dua aturan replikasi
    y0 = 650
    k1, d1 = slide(t, T.s("rf") - 0.1, 0.5, 24)

    def rf_card(img):
        shadow_card(img, (60, y0 + d1, 940, y0 + 230 + d1))
        text(img, (96, y0 + 52 + d1), "replication factor = 3", font("monob", 34), BLUE, anchor="lm")
        text(img, (96, y0 + 112 + d1), "setiap data disalin ke 3 node", font("semi", 32), INK, anchor="lm")
        for i in range(3):
            chip(img, 96 + i * 150, y0 + 178 + d1, f"node {i + 1}", color=BLUE, bg=BLUE_BG, anchor="l")
    group(im, k1, rf_card)
    k2, d2 = slide(t, t_mis - 0.15, 0.5, 24)

    def mis_card(img):
        shadow_card(img, (980, y0 + d2, 1860, y0 + 230 + d2), border=GREEN, bw=3)
        text(img, (1016, y0 + 52 + d2), "min.insync.replicas = 2", font("monob", 34), GREEN, anchor="lm")
        rich(img, 1016, y0 + 88 + d2, [("Tulisan", font("semi", 32), INK), ("acks=all", font("monob", 30), INK),
                                       ("hanya diterima kalau minimal 2 salinan sinkron", font("semi", 32), INK)],
             800, 46)
    group(im, k2, mis_card)
    caption(im, "Node 1 di host 177 · node 2 dan 3 di host 181", window(t, T.e("place") + 0.1, T.s("rf") + 0.2))
    fade_scene(im, t, T.dur)


# =====================================================================
# Adegan 3 — Aturan mayoritas
# =====================================================================
SEATS = [(230, 272), (480, 272), (730, 272)]


def scene3(im, t, T):
    chrome(im, 3, "Aturan mayoritas KRaft")
    t_need = T.w("need", "mayoritas")
    t_noctl = T.s("noctl")
    t_177 = T.s("c177")
    t_181 = T.s("c181")
    t_spof = T.s("spof")

    # --- panel kursi voter ---
    def seats_state():
        if t < t_need - 0.3:
            return ["wait"] * 3, 0.0
        if t < t_177 - 0.1:
            v = clamp((t - (t_need - 0.3)) / 1.2) * 3
            return ["on" if v >= i + 0.5 else "wait" for i in range(3)], v
        if t < t_181 - 0.1:
            return ["off", "on", "on"], 2.0
        return ["on", "off", "off"], 1.0

    states, votes = seats_state()
    kp = prog(t, 0.1, 0.5)

    def seat_panel(img):
        shadow_card(img, (60, 130, 900, 600))
        text(img, (96, 172), "3 voter · quorum controller", font("bold", 32), INK, anchor="lm")
        for i, ((cx, cy), st) in enumerate(zip(SEATS, states)):
            seat(img, (cx, cy), 66, i + 1, st)
            host = "177" if i == 0 else "181"
            text(img, (cx, cy + 92), f"host {host}", font("semi", 28), MUTED, anchor="mm")
        vote_meter(img, 140, 490, votes)
        ok = votes >= 2
        if t >= t_need + 0.9:
            s = "controller ada" if ok else "tidak ada controller"
            group(img, prog(t, t_need + 0.9, 0.3),
                  lambda im2: pill(im2, 480, 430, s, font("bold", 30), fg=GREEN if ok else RED,
                                   bg=GREEN_BG if ok else RED_BG, anchor="c", outline=GREEN if ok else RED,
                                   padx=18, h=48))
    group(im, kp, seat_panel)

    # --- panel "tanpa controller" ---
    kn, dn = slide(t, t_noctl - 0.1, 0.5, 24)

    def noctl(img):
        shadow_card(img, (960, 130 + dn, 1860, 600 + dn), border=RED, bw=2)
        text(img, (996, 172 + dn), "Tanpa controller:", font("bold", 32), RED, anchor="lm")
        items = [("leader tidak bisa dipindah", None), ("ISR tidak bisa dikecilkan", "ISR = daftar replika sinkron"),
                 ("broker tidak bisa mendaftar", None)]
        for i, (s, sub) in enumerate(items):
            ki = prog(t, t_noctl + 0.2 + i * 0.7, 0.4)
            yy = 262 + i * 110 + dn

            def row(im2, s=s, sub=sub, yy=yy):
                icon_cross(im2, (1016, yy), 22, RED, RED_BG)
                text(im2, (1056, yy - (14 if sub else 0)), s, font("semi", 34), INK, anchor="lm")
                if sub:
                    text(im2, (1056, yy + 28), sub, font("sans", 28), MUTED, anchor="lm")
            group(img, ki, row)
    group(im, kn, noctl)

    # --- tabel skenario ---
    kt = prog(t, t_177 - 0.2, 0.5)

    def table(img):
        x0, y0, x1 = 60, 636, 1860
        shadow_card(img, (x0, y0, x1, y0 + 290))
        cols = [96, 470, 1120, 1380]
        for c, s in zip(cols, ["Skenario", "Voter tersisa", "Suara", "Hasil"]):
            text(img, (c, y0 + 36), s, font("semi", 28), MUTED, anchor="lm")
        rrect(img, (x0 + 2, y0 + 69, x1 - 2, y0 + 71), r=0, fill=LINE)
        rows = [(t_177, "177 mati", "node 2, node 3 (di 181)", "2/3", True, "cluster jalan"),
                (t_181, "181 mati", "node 1 (di 177)", "1/3", False, "cluster lumpuh")]
        for i, (tr, a, b, c, ok, res) in enumerate(rows):
            kr = prog(t, tr - 0.1, 0.4)
            cy = y0 + 125 + i * 104
            hl = window(t, tr - 0.1, tr + 2.4) if ok else max(window(t, tr - 0.1, t_spof), prog(t, t_spof, 0.4))
            if hl > 0.004:
                rrect(img, (x0 + 14, cy - 46, x1 - 14, cy + 46), r=12,
                      fill=(GREEN_BG if ok else RED_BG) + (int(255 * hl),))

            def row(im2, a=a, b=b, c=c, ok=ok, res=res, cy=cy):
                text(im2, (cols[0], cy), a, font("bold", 34), INK, anchor="lm")
                text(im2, (cols[1], cy), b, font("semi", 32), INK, anchor="lm")
                text(im2, (cols[2], cy), c, font("xbold", 40), GREEN if ok else RED, anchor="lm")
                (icon_check if ok else icon_cross)(im2, (cols[3] + 22, cy), 22, GREEN if ok else RED,
                                                   GREEN_BG if ok else RED_BG)
                text(im2, (cols[3] + 60, cy), res, font("bold", 34), GREEN if ok else RED, anchor="lm")
            group(img, kr, row)
    group(im, kt, table)
    caption(im, "181 = titik gagal tunggal: 2 dari 3 voter ada di sana", prog(t, t_spof - 0.1, 0.5))
    fade_scene(im, t, T.dur)


# =====================================================================
# Adegan 4 — Malam 29 Oktober
# =====================================================================
def scene4(im, t, T):
    chrome(im, 4, "Malam 29 Oktober 2026")
    t_rb = T.w("reboot", "host 181")
    header_pill(im, "±19:17 WIB · 181 reboot", prog(t, t_rb, 0.4), kind="red")
    t_alive = T.s("alive")
    t_ask = T.s("ask")
    t_pv = T.w("count", "7.214")
    t_cd = T.w("count", "80 kali")
    t_fail = T.s("fail")
    t_logs = T.w("logs", "69.458")
    kd = prog(t, t_rb, 0.6)

    # host 181 (kanan atas): meredup
    host_frame(im, (860, 130, 1860, 400), "181", down=kd,
               note="reboot · IO stall tinggi sebelumnya" if kd > 0.5 else None)
    for n, x in ((2, 890), (3, 1375)):
        node_card(im, x, 210, 455, n, h=160, state="down" if kd > 0.5 else "ok", dim=0.6 * kd,
                  roles=False, port=False)
    if kd > 0.5:
        group(im, prog(t, t_rb + 0.6, 0.4),
              lambda img: text(img, (1360, 426), "node-exporter 181 tidak terjangkau ±19–23 WIB",
                               font("sans", 28), MUTED, anchor="mm"))

    # host 177 + kafka-1 (kiri atas)
    host_frame(im, (60, 130, 800, 620), "177", hl=window(t, t_alive - 0.1, t_alive + 2.0), note=" ")
    asking = t >= t_ask - 0.1
    period = 1.3
    ph = ((t - t_ask) % period) / period if asking else 0.0
    kt = clamp((ph - 0.7) / 0.3) if t >= t_fail - 0.2 else 0.0

    def k1_extra(img, x, y, w, h):
        # proses tetap jalan, tidak restart
        ka = prog(t, t_alive, 0.4)
        group(img, ka, lambda im2: text(im2, (x + w - 26, y + h - 42), "jalan sejak 28 Okt 17:07",
                                        font("sans", 28), MUTED, anchor="rm"))
        # meter suara; tiap percobaan berakhir "Election timed out"
        my = y + 196
        vote_meter(img, x + 26, my, 1 if asking else 0, label=False, sw=80, sh=34)
        lx = x + 26 + 3 * 92 + 14
        if kt > 0:
            group(img, math.sin(kt * math.pi), lambda im2: pill(im2, lx, my + 17, "Election timed out",
                                                                 font("monob", 28), fg=RED, bg=RED_BG,
                                                                 anchor="l", outline=RED, padx=14, h=44))
        else:
            st = "1/3 suara · butuh 2" if asking else "menunggu suara"
            text(img, (lx, my + 17), st, font("bold", 30), RED if asking else MUTED, anchor="lm")

    node_card(im, 100, 290, 660, 1, h=314, state="limbo" if kd > 0.5 else "ok", extra=k1_extra)
    if asking:
        a = min(1.0, ph * 6, (1 - ph) * 5)
        group(im, a, lambda img: bubble(img, 420, 286, "boleh saya mencalonkan diri?", x0=296))

    # penghitung (kiri bawah)
    kc, dc = slide(t, t_pv - 1.0, 0.5, 20)

    def counters(img):
        y0 = 650 + dc
        shadow_card(img, (60, y0, 800, y0 + 282))
        counter_row(img, 96, y0 + 52, 664, "pre-vote", "tahap Prospective", N_PREVOTE, YELLOW,
                    k=count_up(t, t_pv - 1.0, 1.6))
        rrect(img, (80, y0 + 96, 780, y0 + 98), r=0, fill=LINE)
        counter_row(img, 96, y0 + 142, 664, "Candidate", "mencalonkan diri", N_CANDIDATE, YELLOW,
                    k=count_up(t, t_cd - 0.6, 1.0))
        rrect(img, (80, y0 + 186, 780, y0 + 188), r=0, fill=LINE)
        counter_row(img, 96, y0 + 232, 664, "baris log", "±3 jam", N_LOGLINES, INK,
                    k=count_up(t, t_logs - 1.2, 1.6))
    group(im, kc, counters)

    # log yang menumpuk (kanan bawah)
    kl, dl = slide(t, t_ask - 0.2, 0.5, 20)
    group(im, kl, lambda img: log_card(img, (860, 460 + dl, 1860, 932 + dl), t, t_ask, 2.2))
    caption(im, "Hanya 1 dari 3 suara: setiap pemilihan gagal (timeout)", window(t, t_fail - 0.1, t_logs - 1.5))
    fade_scene(im, t, T.dur)
# =====================================================================
# Adegan 5 — Apa yang berhenti
# =====================================================================
def scene5(im, t, T):
    chrome(im, 5, "Selama 181 mati: apa yang berhenti?")
    header_pill(im, "±19:17 – 22:25 WIB", prog(t, 0.2, 0.5))
    t_pr = T.s("produce")
    t_gr = T.s("group")
    t_mid = T.e("group") + 0.05
    t_run = T.s("running")
    t_neq = T.s("neq")
    S, M, B = font("semi", 28), font("mono", 26), font("bold", 32)
    rows = [
        (t_pr, "Produce", "acks=all", "err", "ditolak",
         [("hanya 1 replika hidup <", S, INK), ("min.insync.replicas=2", font("monob", 26), INK)], None),
        (t_gr, "Consumer group", "join · rebalance · commit offset", "err", f"{fmt_id(N_GROUP_TIMEOUT)}× timeout",
         [("tulis ke", S, INK), ("__consumer_offsets", font("monob", 26), INK), ("butuh 2 replika in-sync", S, INK)],
         "grup: " + GROUPS[0] + ", " + GROUPS[1]),
        (t_mid, "Consume data lama", None, "warn", "tak bisa diandalkan",
         [("leader tidak bisa dipindah tanpa controller", S, INK)], None),
        (t_mid + 0.5, "Bikin topic", None, "err", "gagal", [("butuh controller", S, INK)], None),
        (t_run, "Container kafka-1", None, "ok", "running", [("port 9092 menerima koneksi", S, INK)], None),
    ]
    heights = [100, 150, 100, 92, 100]
    kc = prog(t, 0.1, 0.5)

    def table(img):
        x0, y0, x1 = 60, 130, 1860
        tot = 64 + sum(heights) + 10
        shadow_card(img, (x0, y0, x1, y0 + tot))
        cols = [96, 700, 1100]
        for c, s in zip(cols, ["Operasi", "Status", "Kenapa"]):
            text(img, (c, y0 + 34), s, font("semi", 28), MUTED, anchor="lm")
        rrect(img, (x0 + 2, y0 + 63, x1 - 2, y0 + 65), r=0, fill=LINE)
        yy = y0 + 66
        for (tr, op, sub, kind, st, why, extra), h in zip(rows, heights):
            kr = prog(t, tr - 0.1, 0.4)
            col, bgc = {"err": (RED, RED_BG), "warn": (YELLOW, YELLOW_BG), "ok": (GREEN, GREEN_BG)}[kind]
            hl = window(t, tr - 0.1, tr + 2.2) if kind != "ok" else prog(t, tr - 0.1, 0.4)
            if kind == "ok" and t >= t_neq:
                hl = 1.0
            if hl * kr > 0.004:
                rrect(img, (x0 + 12, yy + 4, x1 - 12, yy + h - 4), r=12, fill=bgc + (int(200 * hl * kr),))

            def row(im2, op=op, sub=sub, kind=kind, st=st, why=why, extra=extra, yy=yy, h=h, col=col, bgc=bgc):
                top = yy + (34 if (sub or extra) else h / 2)
                text(im2, (cols[0], top), op, B, INK, anchor="lm")
                if sub:
                    text(im2, (cols[0], top + 40), sub, M, MUTED, anchor="lm")
                c = (cols[1] + 22, top)
                if kind == "err":
                    icon_cross(im2, c, 22, RED, RED_BG)
                elif kind == "ok":
                    icon_check(im2, c, 22, GREEN, GREEN_BG)
                else:
                    circle(im2, c, 22, fill=YELLOW_BG)
                    text(im2, (c[0], c[1] + 1), "!", font("xbold", 30), YELLOW, anchor="mm")
                text(im2, (cols[1] + 58, top), st, font("bold", 32), col, anchor="lm")
                rich(im2, cols[2], top - 22, why, 720, 44)
                if extra:
                    rich(im2, cols[2], top + 22, [(extra, font("mono", 24), MUTED)], 720, 34)
            group(img, kr, row)
            yy += h
    group(im, kc, table)

    kb, db = slide(t, t_neq - 0.15, 0.5, 20)

    def banner(img):
        f = font("xbold", 52)
        s1, s2 = "running", "  ≠  melayani"
        wt = tw(s1, font("monob", 50)) + tw(s2, f)
        x0 = 960 - wt / 2 - 50
        y0 = 836 + db
        rrect(img, (x0, y0, 1920 - x0, y0 + 104), r=52, fill=YELLOW_BG, outline=YELLOW, width=3)
        text(img, (x0 + 50, y0 + 53), s1, font("monob", 50), GREEN, anchor="lm")
        text(img, (x0 + 50 + tw(s1, font("monob", 50)), y0 + 53), s2, f, INK, anchor="lm")
    group(im, kb, banner)
    if t < t_neq - 0.2:
        caption(im, "Dari sisi aplikasi, Kafka terasa down", prog(t, t_run + 0.6, 0.4) - prog(t, t_neq - 0.6, 0.4))
    fade_scene(im, t, T.dur)


# =====================================================================
# Adegan 6 — 22:25:32, pulih sendiri
# =====================================================================
def scene6(im, t, T):
    chrome(im, 6, "22:25:32 WIB — pulih sendiri")
    t_back = T.w("back", "host 181")
    t_el = T.s("elect")
    t_safe = T.s("safe")
    t_app = T.s("app")
    t_lost = T.s("lost")
    up = prog(t, t_back, 0.7)
    votes = 1 + 2 * clamp((t - (t_el - 0.2)) / 0.9)
    elected = t >= t_el + 0.8

    # garis waktu
    def timeline(img):
        x0, x1, y = 120, 1800, 168
        text(img, (x0, y - 34), "±19:17 · 181 reboot", font("semi", 28), RED, anchor="lm")
        text(img, (x1, y - 34), "22:25:32 · 181 kembali", font("semi", 28), GREEN if up > 0.5 else MUTED,
             anchor="rm")
        rrect(img, (x0, y, x1, y + 14), r=7, fill=RED_BG)
        mk = lerp(x0 + (x1 - x0) * 0.82, x1, up)
        rrect(img, (x0, y, mk, y + 14), r=7, fill=RED)
        text(img, ((x0 + x1) / 2, y + 44), "±3 jam tanpa controller", font("semi", 28), RED, anchor="mm")
        circle(img, (mk, y + 7), 14, fill=GREEN if up > 0.5 else RED)
    timeline(im)

    # cluster
    host_frame(im, (60, 246, 800, 566), "177", note=" ")
    host_frame(im, (860, 246, 1860, 566), "181", down=1 - up, note=" ")

    def k1_extra(img, x, y, w, h):
        my = y + 100
        vote_meter(img, x + 26, my, votes, label=False, sw=80, sh=34)
        ok = votes >= 2
        text(img, (x + 26 + 3 * 92 + 14, my + 17), f"{int(round(votes))}/3 suara", font("bold", 30),
             GREEN if ok else RED, anchor="lm")
        if elected:
            group(img, prog(t, t_el + 0.8, 0.3), lambda im2: pill(im2, x + w - 26, y + h - 42, "controller terpilih",
                                                                   font("bold", 28), fg=GREEN, bg=GREEN_BG,
                                                                   anchor="r", outline=GREEN, padx=14, h=44))
    node_card(im, 100, 316, 660, 1, h=220, state="ok" if elected else "limbo", extra=k1_extra,
              roles=False, port=False)
    for n, x in ((2, 890), (3, 1375)):
        node_card(im, x, 316, 455, n, h=220, state="ok" if up > 0.5 else "down", dim=0.6 * (1 - up), port=False)
    # replikasi jalan lagi: panah fetcher kafka-1 <- kafka-2
    kr = prog(t, t_el + 1.2, 0.6)
    if kr > 0:
        arrow(im, [(888, 500), (764, 500)], GREEN, 5, 18, k=kr)
        group(im, kr, lambda img: text(img, (830, 468), "replikasi", font("semi", 28), GREEN, anchor="mm"))
    group(im, prog(t, T.w("elect", "tanpa restart") - 0.1, 0.4),
          lambda img: pill(img, 1840, 286, "tanpa restart · tanpa campur tangan", font("semi", 28), fg=GREEN,
                           bg=GREEN_BG, anchor="r", outline=GREEN, padx=16, h=44))

    # kartu: data aman
    ks, ds = slide(t, t_safe - 0.1, 0.5, 24)

    def safe(img):
        x0, y0 = 60, 600 + ds
        shadow_card(img, (x0, y0, x0 + 880, y0 + 330), border=GREEN, bw=3)
        rrect(img, (x0 + 3, y0 + 3, x0 + 877, y0 + 76), r=16, fill=GREEN_BG)
        icon_check(img, (x0 + 46, y0 + 40), 20, GREEN)
        text(img, (x0 + 80, y0 + 40), "Data di Kafka aman", font("bold", 36), GREEN, anchor="lm")
        rich(img, x0 + 36, y0 + 96, [("Ditolak, bukan dibuang:", font("bold", 32), INK),
                                     ("tulisan tidak pernah diterima lalu dibuang.", font("semi", 32), INK)], 810, 46)
        rich(img, x0 + 36, y0 + 200, [("Truncation ke offset > 0 setelah outage:", font("semi", 30), MUTED),
                                      ("0", font("monob", 30), GREEN)], 810, 42)
        rich(img, x0 + 36, y0 + 250, [("berkat", font("semi", 30), MUTED),
                                      ("min.insync.replicas=2", font("monob", 28), GREEN)], 810, 42)
    group(im, ks, safe)

    ka, da = slide(t, t_app - 0.1, 0.5, 24)

    def app(img):
        x0, y0 = 980, 600 + da
        shadow_card(img, (x0, y0, x0 + 880, y0 + 330), border=YELLOW, bw=3)
        rrect(img, (x0 + 3, y0 + 3, x0 + 877, y0 + 76), r=16, fill=YELLOW_BG)
        icon_retry(img, (x0 + 46, y0 + 40), 16, 0.4, YELLOW, 5)
        text(img, (x0 + 80, y0 + 40), "Risiko di sisi aplikasi", font("bold", 36), YELLOW, anchor="lm")
        rich(img, x0 + 36, y0 + 96, [("Pesan ditolak kembali sebagai error setelah producer menyerah (default",
                                      font("semi", 30), INK), ("delivery.timeout.ms", font("monob", 28), INK),
                                     ("120 dtk).", font("semi", 30), INK)], 810, 42)
        kw = prog(t, t_app + 1.0, 0.4)
        group(img, kw, lambda im2: rich(im2, x0 + 36, y0 + 192, [("Wajib: simpan + retry.", font("bold", 32), YELLOW)],
                                        810, 44))
        kl = prog(t, t_lost - 0.1, 0.4)
        group(img, kl, lambda im2: rich(im2, x0 + 36, y0 + 248,
                                        [("Konfigurasi producer aplikasi belum dicek: ini risiko, bukan temuan.",
                                          font("sans", 28), MUTED)], 810, 36))
    group(im, ka, app)
    fade_scene(im, t, T.dur)
# =====================================================================
# Adegan 7 — Jebakan
# =====================================================================
def trap_card(im, x0, title, alpha, dy):
    def fn(img):
        y0 = 140 + dy
        shadow_card(img, (x0, y0, x0 + 880, y0 + 760), border=RED, bw=3, lift=1.4)
        rrect(img, (x0 + 3, y0 + 3, x0 + 877, y0 + 80), r=16, fill=RED_BG)
        icon_cross(img, (x0 + 46, y0 + 42), 22, RED, WHITE)
        text(img, (x0 + 84, y0 + 42), title, font("bold", 36), RED, anchor="lm")
    group(im, alpha, fn)


def scene7(im, t, T):
    chrome(im, 7, "Jebakan: dua langkah yang tidak menolong")
    t_m = T.s("move")
    t_maj = T.w("move2", "mayoritas")
    t_pindah = T.w("move2", "titik gagal")
    t_r = T.s("restart")
    t_st = T.w("restart", "tertahan")

    k1, d1 = slide(t, t_m - 0.15, 0.5, 30)
    trap_card(im, 60, "Pindah voter ke 177", k1, d1)

    def card1(img):
        y0 = 140 + d1
        # dua host: 177 berisi 2 voter, 181 berisi 1 voter
        dead177 = prog(t, t_pindah, 0.5)
        host_frame(img, (100, y0 + 110, 560, y0 + 350), "177", down=dead177, note=" ")
        host_frame(img, (600, y0 + 110, 900, y0 + 350), "181", note=" ")
        st = "down" if dead177 > 0.5 else "voter"
        mini_node(img, (230, y0 + 262), "V", state=st, s=96)
        mini_node(img, (420, y0 + 262), "V", state=st, s=96)
        mini_node(img, (750, y0 + 262), "V", state="limbo" if dead177 > 0.5 else "voter", s=96)
        text(img, (900, y0 + 380), "V = voter", font("sans", 28), MUTED, anchor="rm")
        kmaj = prog(t, t_maj - 0.1, 0.4)
        group(img, kmaj, lambda im2: rich(im2, 100, y0 + 410,
                                          [("Dengan 2 host, mayoritas (2 dari 3) selalu ada di satu host.",
                                            font("semi", 32), INK)], 800, 46))
        kp = prog(t, t_pindah, 0.4)
        group(img, kp, lambda im2: (pill(im2, 100, y0 + 540, "177 mati → 1/3 suara → lumpuh", font("bold", 32), fg=RED,
                                         bg=RED_BG, anchor="l", outline=RED, padx=18, h=54),
                                    rich(im2, 100, y0 + 600, [("Titik gagal hanya pindah ke 177, yang juga punya riwayat "
                                                               "disk error dan mati listrik.", font("semi", 30), INK)],
                                         800, 44)))
    group(im, k1, card1)

    k2, d2 = slide(t, t_r - 0.15, 0.5, 30)
    trap_card(im, 980, "Restart kafka-1 saat 181 mati", k2, d2)

    def card2(img):
        x0, y0 = 980, 140 + d2
        host_frame(img, (x0 + 40, y0 + 110, x0 + 840, y0 + 350), "181", down=1.0, note="masih mati")
        mini_node(img, (x0 + 330, y0 + 262), 2, state="down", s=96)
        mini_node(img, (x0 + 550, y0 + 262), 3, state="down", s=96)
        # status kafka-1: running -> restart -> STARTING (tertahan)
        ph = clamp((t - (t_r + 0.6)) / 1.2)
        text(img, (x0 + 40, y0 + 400), "kafka-1", font("monob", 34), INK, anchor="lm")
        if ph < 0.5:
            status_pill(img, x0 + 220, y0 + 400, "running")
        elif t < t_st - 0.1:
            icon_retry(img, (x0 + 250, y0 + 400), 20, (t - t_r) * 4, MUTED, 5)
            text(img, (x0 + 284, y0 + 400), "restart…", font("semi", 30), MUTED, anchor="lm")
        else:
            b = status_pill(img, x0 + 220, y0 + 400, "starting")
            spinner(img, (b[2] + 34, y0 + 400), 18, t, YELLOW, 5)
        ks = prog(t, t_st - 0.1, 0.4)
        group(img, ks, lambda im2: (rich(im2, x0 + 40, y0 + 460,
                                         [("Broker tidak bisa mendaftar ke controller, jadi akan tertahan di "
                                           "status", font("semi", 32), INK), ("STARTING", font("monob", 30), YELLOW)],
                                         800, 46),
                                    rich(im2, x0 + 40, y0 + 620, [("Perilaku KRaft — belum teramati langsung "
                                                                   "di kejadian ini.", font("sans", 28), MUTED)],
                                         800, 38)))
    group(im, k2, card2)
    caption(im, "Keduanya tidak menghapus titik gagal tunggal", prog(t, T.e("restart") - 0.3, 0.5))
    fade_scene(im, t, T.dur)


# =====================================================================
# Adegan 8 — Ringkasan + pilihan
# =====================================================================
def scene8(im, t, T):
    chrome(im, 8, "Ringkasan")
    group(im, prog(t, 0.1, 0.6), lambda img: text(img, (56, 128), "Kafka tidak mati, ia kalah suara",
                                                  font("semi", 32), GREEN, anchor="lm"))
    S = font("semi", 36)
    M = font("monob", 34)
    B = font("xbold", 36)
    pts = [("p1", [("kafka-1", M, GREEN), ("tidak rusak: ia “mati suri” karena kalah suara, lalu pulih sendiri.", S, INK)]),
           ("p2", [("Akar masalah = desain:", B, INK), ("2 dari 3 voter", S, INK), ("ada di host 181.", S, INK)])]
    for i, (key, parts) in enumerate(pts):
        ks, dys = slide(t, T.s(key) - 0.2, 0.55, 30)
        y0 = 166 + i * 130

        def card(img, i=i, parts=parts, y0=y0, dys=dys):
            yy = y0 + dys
            shadow_card(img, (160, yy, 1760, yy + 112), lift=1.2)
            circle(img, (226, yy + 56), 34, fill=GREEN)
            text(img, (226, yy + 58), str(i + 1), font("bold", 36), WHITE, anchor="mm")
            rich(img, 286, yy + 56 - 26, parts, 1440, 52)
        group(im, ks, card)

    kp, dp = slide(t, T.s("o1") - 0.3, 0.55, 30)
    opts = [("o1", "Voter ketiga di host ketiga yang benar-benar independen",
             "cukup controller-only ringan · jangan di host 51: sumber tekanan yang membuat 181 freeze"),
            ("o2", "Primary / standby",
             "cluster utuh di 181 · 177 standby terpisah (cluster sendiri + replikasi, atau backup)"),
            ("o3", "Perbaiki sumber freeze malam di 181",
             "backup rsync di 51 · paling murah, tapi titik gagal tunggal tetap ada")]

    def card3(img):
        yy = 436 + dp
        shadow_card(img, (160, yy, 1760, yy + 500), lift=1.2)
        circle(img, (226, yy + 50), 34, fill=GREEN)
        text(img, (226, yy + 52), "3", font("bold", 36), WHITE, anchor="mm")
        text(img, (286, yy + 50), "Pilihan perbaikan", font("xbold", 36), INK, anchor="lm")
        pill(img, 1730, yy + 50, "pilihan · belum dikerjakan", font("semi", 28), fg=YELLOW, bg=YELLOW_BG,
             anchor="r", outline=YELLOW, padx=16, h=46)
        rrect(img, (162, yy + 99, 1758, yy + 101), r=0, fill=LINE)
        for j, (key, head, sub) in enumerate(opts):
            ko = prog(t, T.s(key) - 0.15, 0.45)
            oy = yy + 116 + j * 128

            def opt(im2, j=j, head=head, sub=sub, oy=oy, key=key):
                hl = window(t, T.s(key) - 0.15, T.e(key) + 0.2, 0.3)
                if hl > 0.004:
                    rrect(im2, (180, oy, 1740, oy + 116), r=14, fill=GREEN_BG + (int(255 * hl),))
                pill(im2, 216, oy + 38, "ABC"[j], font("bold", 30), fg=GREEN, bg=WHITE, anchor="c",
                     outline=GREEN, padx=14, h=48)
                text(im2, (264, oy + 38), head, font("bold", 34), INK, anchor="lm")
                text(im2, (264, oy + 84), sub, font("semi", 28), MUTED, anchor="lm")
            group(img, ko, opt)
    group(im, kp, card3)
    fade_scene(im, t, T.dur)


SCENE_FUNCS = {1: scene1, 2: scene2, 3: scene3, 4: scene4, 5: scene5, 6: scene6, 7: scene7, 8: scene8}
