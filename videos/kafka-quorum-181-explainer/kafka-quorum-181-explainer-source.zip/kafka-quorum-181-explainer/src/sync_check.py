"""Cek sinkronisasi sorotan vs narasi.

Animasi ditambatkan ke T.w(kalimat, frasa): perkiraan waktu frasa diucapkan (interpolasi
per karakter di dalam kalimat). Untuk mengujinya secara independen, potongan kalimat SEBELUM
frasa disintesis ulang dengan Piper; durasi ucapan potongan itu = perkiraan kedua kapan frasa
dimulai. Selisih kedua perkiraan dilaporkan. Keluaran: build/sync_report.txt"""
import sys
from pathlib import Path

import numpy as np
from piper import PiperVoice, SynthesisConfig

sys.path.insert(0, str(Path(__file__).parent))
from components import Timing  # noqa: E402
from narration import to_tts  # noqa: E402
from tts import LENGTH_SCALE, MODEL, speech_bounds  # noqa: E402

# frasa yang dipakai sebagai isyarat di scenes.py (selain awal kalimat yang waktunya pasti)
CUES = [
    (1, "q1", "host 181"), (1, "motto", "kalah suara"),
    (2, "nodes", "broker"), (2, "nodes", "controller"), (2, "place", "host 177"), (2, "place", "host 181"),
    (2, "rf", "3 salinan"), (2, "rf", "tulisan butuh"),
    (3, "need", "mayoritas"),
    (4, "reboot", "host 181"), (4, "count", "80 kali"), (4, "logs", "69.458"),
    (6, "back", "host 181"), (6, "elect", "tanpa restart"),
    (7, "move2", "mayoritas"), (7, "move2", "titik gagal"), (7, "restart", "tertahan"),
]


def main():
    v = PiperVoice.load(str(MODEL))
    cfg = SynthesisConfig(length_scale=LENGTH_SCALE, noise_scale=0.6, noise_w_scale=0.7)
    out, errs = [], []
    for sid, key, phrase in CUES:
        T = Timing(sid)
        sg = T.seg[key]
        est = T.w(key, phrase) - sg["start"]
        prefix = sg["text"][: sg["text"].index(phrase)].rstrip(" ,:")
        durs = []
        for _ in range(3):
            a = np.concatenate([c.audio_int16_array for c in v.synthesize(to_tts(prefix), syn_config=cfg)])
            on, off = speech_bounds(a)
            durs.append(off - on)
        ref = float(np.median(durs)) + 0.08  # + jeda singkat di batas kata/koma
        err = est - ref
        errs.append(abs(err))
        out.append(f"adegan {sid} {key:8s} '{phrase}': perkiraan {est:5.2f} dtk, cek {ref:5.2f} dtk, selisih {err:+.2f}")
    out.append(f"selisih maksimum {max(errs):.2f} dtk, rata-rata {np.mean(errs):.2f} dtk, "
               f"{sum(e <= 0.5 for e in errs)}/{len(errs)} isyarat dalam 0,5 dtk")
    (Path(__file__).resolve().parent.parent / "build/sync_report.txt").write_text("\n".join(out))
    print("\n".join(out))


if __name__ == "__main__":
    main()
