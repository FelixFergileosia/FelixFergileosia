"""Membuat audio narasi per adegan dengan Piper (model id_ID-news_tts-medium, offline).

Keluaran:
  build/audio/scene_XX.wav      audio narasi satu adegan (mono 22.05 kHz, termasuk jeda)
  build/audio/clips/*.wav       klip per kalimat (untuk pemeriksaan)
  build/timing.json             waktu tiap kalimat & perkiraan waktu tiap kata, relatif ke adegan

Aturan durasi: durasi adegan = lead-in + audio narasi + 0,8 detik jeda.
"""
import json
import re
import sys
import wave
from pathlib import Path

import numpy as np
from piper import PiperVoice, SynthesisConfig

sys.path.insert(0, str(Path(__file__).parent))
from narration import SCENES, spoken_numbers, to_tts  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
MODEL = ROOT / "models/vits-piper-id_ID-news_tts-medium/id_ID-news_tts-medium.onnx"
OUT = ROOT / "build"
SR = 22050
LEAD = 0.35      # diam di awal adegan sebelum narasi
GAP = 0.32       # jeda antar kalimat
TAIL = 0.8       # jeda di akhir adegan (sesuai spesifikasi)
LENGTH_SCALE = 0.9   # tempo bicara; disetel agar total durasi masuk 120-160 dtk


def synth(voice, text):
    cfg = SynthesisConfig(length_scale=LENGTH_SCALE, noise_scale=0.6, noise_w_scale=0.7)
    chunks = [c.audio_int16_array for c in voice.synthesize(text, syn_config=cfg)]
    return np.concatenate(chunks).astype(np.int16)


def frame_rms(a, win):
    n = len(a) // win
    x = a[: n * win].astype(np.float32).reshape(n, win)
    return np.sqrt((x ** 2).mean(axis=1))


def speech_bounds(a):
    """Awal & akhir suara (detik) di dalam klip."""
    win = int(SR * 0.01)
    r = frame_rms(a, win)
    thr = max(r.max() * 0.04, 60)
    idx = np.where(r > thr)[0]
    return idx[0] * 0.01, (idx[-1] + 1) * 0.01


def pauses(a, on, off):
    """Jeda internal (>=90 ms) di antara awal & akhir suara -> daftar titik tengah jeda (detik)."""
    win = int(SR * 0.01)
    r = frame_rms(a, win)
    thr = max(r.max() * 0.04, 60)
    quiet = r <= thr
    res, start = [], None
    lo, hi = int(on / 0.01), int(off / 0.01)
    for i in range(lo, hi):
        if quiet[i] and start is None:
            start = i
        elif not quiet[i] and start is not None:
            if i - start >= 9:
                res.append(((start + i) / 2) * 0.01)
            start = None
    return res


def word_times(text_tts, on, off, gaps):
    """Perkiraan waktu mulai tiap karakter-teks: interpolasi proporsional per frasa.
    Batas frasa (koma/titik dua) dijangkarkan ke jeda yang terdeteksi bila jumlahnya cocok."""
    parts = [m.end() for m in re.finditer(r"[,:;]\s*", text_tts)]
    anchors_c = [0] + parts + [len(text_tts)]
    if len(gaps) == len(parts):
        anchors_t = [on] + gaps + [off]
        mode = "jeda"
    else:
        anchors_t = [on + (off - on) * c / len(text_tts) for c in anchors_c]
        mode = "proporsional"
    return anchors_c, anchors_t, mode


N_CAND = 6
_REC = None
# ejaan Whisper yang setara dengan istilah di naskah (dibandingkan setelah huruf kecil)
EQUIV = {"kontroler": "controller", "kontroller": "controller", "konsumer": "consumer", "voters": "voter",
         "kraf": "kraft", "kafkah": "kafka", "note": "node", "x": "acks", "replica": "replika"}


def norm_words(s):
    """Huruf kecil, angka -> kata (dari naskah maupun dari Whisper), tanda baca dibuang."""
    s = re.sub(r"(\d),(\d{3})\b", r"\1\2", s)
    s = spoken_numbers(s).lower()
    w = re.sub(r"[^a-z0-9 ]+", " ", s).split()
    return [EQUIV.get(x, x) for x in w]


def asr_score(a, ref_text):
    """Kecocokan kata hasil Whisper vs naskah. Angka di kedua sisi diubah ke kata dulu,
    jadi ucapan angka ikut diperiksa."""
    global _REC
    from difflib import SequenceMatcher
    import sherpa_onnx
    m = ROOT / "models/asr/sherpa-onnx-whisper-small"
    if _REC is None:
        _REC = sherpa_onnx.OfflineRecognizer.from_whisper(
            encoder=str(m / "small-encoder.int8.onnx"), decoder=str(m / "small-decoder.int8.onnx"),
            tokens=str(m / "small-tokens.txt"), language="id", task="transcribe", num_threads=2)
    pad = np.zeros(int(SR * 0.3), np.float32)
    st = _REC.create_stream()
    st.accept_waveform(SR, np.concatenate([pad, a.astype(np.float32) / 32768.0, pad]))
    _REC.decode_stream(st)
    hyp = st.result.text.strip()
    return SequenceMatcher(None, norm_words(ref_text), norm_words(hyp)).ratio(), hyp


def main():
    voice = PiperVoice.load(str(MODEL))
    asr_log = []
    (OUT / "audio/clips").mkdir(parents=True, exist_ok=True)
    timing = {}
    for sc in SCENES:
        sid = sc["id"]
        pieces = [np.zeros(int(LEAD * SR), np.int16)]
        t = LEAD
        segs = []
        for key, text in sc["segments"]:
            tts_text = to_tts(text)
            # Piper memberi hasil sedikit berbeda tiap kali. Buat beberapa kandidat,
            # transkripsikan dengan Whisper, ambil yang paling cocok dengan naskah.
            best = None
            for _ in range(N_CAND):
                cand = synth(voice, tts_text)
                score, hyp = asr_score(cand, text)
                if best is None or score > best[0]:
                    best = (score, cand, hyp)
                if score >= 0.999:
                    break
            a = best[1]
            asr_log.append(f"[{sid}/{key}] skor {best[0]:.2f} | {best[2]}")
            on, off = speech_bounds(a)
            gaps = pauses(a, on, off)
            ac, at, mode = word_times(tts_text, on, off, gaps)
            with wave.open(str(OUT / f"audio/clips/s{sid}_{key}.wav"), "wb") as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(a.tobytes())
            dur = len(a) / SR
            segs.append({
                "key": key, "text": text, "tts": tts_text,
                "clip_start": round(t, 3), "clip_dur": round(dur, 3),
                "start": round(t + on, 3), "end": round(t + off, 3),
                "anchors_c": ac, "anchors_t": [round(t + x, 3) for x in at], "anchor_mode": mode,
            })
            pieces.append(a)
            t += dur
            pieces.append(np.zeros(int(GAP * SR), np.int16))
            t += GAP
        # buang GAP terakhir, ganti dengan TAIL
        pieces[-1] = np.zeros(int(TAIL * SR), np.int16)
        t = t - GAP + TAIL
        audio = np.concatenate(pieces)
        with wave.open(str(OUT / f"audio/scene_{sid:02d}.wav"), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(audio.tobytes())
        timing[sid] = {"dur": round(len(audio) / SR, 3), "segments": segs}
        print(f"adegan {sid}: {len(audio)/SR:.2f} dtk  " + ", ".join(f"{s['key']}({s['anchor_mode'][0]})" for s in segs))
    (OUT / "timing.json").write_text(json.dumps(timing, indent=1, ensure_ascii=False))
    (OUT / "tts_selection.txt").write_text("\n".join(asr_log))
    print("total", round(sum(v["dur"] for v in timing.values()), 2), "dtk")


if __name__ == "__main__":
    main()
